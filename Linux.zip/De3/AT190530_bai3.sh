#!/bin/bash

# Xem danh sach o dia co tren linux
lsblk1

# Tao thu muc -p la neu cau truc chua ton tai thi tao ca
mkdir -p /KMA/Security

mkdir /THI

# Thuc hien anh xa o dia cdrom(iso) vao thu muc /KMA/Security
mount /dev/cdrom /KMA/Security

# Copy file bat ky trong /KMA/Security toi o dia goc /THI

echo "Truong Ngoc Lam - AT190530" > flag.txt

cp /KMA/Security/flag.txt /THI/flag.txt
