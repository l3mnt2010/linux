#!/bin/bash

free
# kiểm tra thông tin về bộ nhớ RAM và swap.
# Nó hiển thị dung lượng bộ nhớ đã sử dụng,
# còn trống và được phân bổ.
lsblk
# hiển thị thông tin chi tiết về các thiết
# bị lưu trữ (disk) trên hệ thống dưới dạng cây.
ifconfig
#lscpu
#ip addr show

ifconfig enp0s3 192.168.56.33 netmask 255.255.255.0
systemctl restart NetworkManager
ifconfig | grep mtu
ifconfig enp0s3 mtu 1000

tar -cvf test.tar /test